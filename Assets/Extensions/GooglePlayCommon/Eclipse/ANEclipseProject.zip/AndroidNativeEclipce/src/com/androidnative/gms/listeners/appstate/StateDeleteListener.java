package com.androidnative.gms.listeners.appstate;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.appstate.AppStateManager.StateDeletedResult;
import com.google.android.gms.common.api.ResultCallback;
import com.unity3d.player.UnityPlayer;

public class StateDeleteListener implements ResultCallback<AppStateManager.StateDeletedResult> {

	@Override
	public void onResult(StateDeletedResult arg0) {
		// TODO Auto-generated method stub
		
		int statusCode = arg0.getStatus().getStatusCode();
		Log.d("AndroidNative", "deleteState: " + Integer.toString(statusCode));
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append(arg0.getStateKey());
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_CLOUD_LISTNER_NAME,
				"OnKeyDeleted", result.toString());
		
		
	}

}
