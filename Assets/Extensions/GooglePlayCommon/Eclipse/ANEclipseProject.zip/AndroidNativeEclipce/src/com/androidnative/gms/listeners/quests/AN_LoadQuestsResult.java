package com.androidnative.gms.listeners.quests;

import java.util.Iterator;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.games.quest.Quests;
import com.google.android.gms.games.quest.Quests.LoadQuestsResult;
import com.unity3d.player.UnityPlayer;

public class AN_LoadQuestsResult implements ResultCallback<Quests.LoadQuestsResult> {

	@Override
	public void onResult(LoadQuestsResult r) {
		
		Log.d(AndroidNativeBridge.TAG, "AN_LoadQuestsResult+");
		
		int statusCode = r.getStatus().getStatusCode();
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
			Iterator<Quest> iterator = r.getQuests().iterator();
			while (iterator.hasNext()) {
				
				Quest quest = iterator.next();
				
				result.append(quest.getQuestId());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(quest.getName());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(quest.getDescription());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				result.append(quest.getBannerImageUrl());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(quest.getIconImageUrl());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				result.append(quest.getState());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				
				
				result.append(quest.getLastUpdatedTimestamp());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(quest.getAcceptedTimestamp());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(quest.getEndTimestamp());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				
			}
			
			r.getQuests().close();
			result.append(AndroidNativeBridge.UNITY_EOF);
		}
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_QUESTS_LISTNER_NAME, "OnGPQuestsLoaded", result.toString());
	}

}
