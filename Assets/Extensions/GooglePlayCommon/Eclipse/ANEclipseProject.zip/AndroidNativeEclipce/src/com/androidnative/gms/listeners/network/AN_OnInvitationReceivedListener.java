package com.androidnative.gms.listeners.network;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.unity3d.player.UnityPlayer;

public class AN_OnInvitationReceivedListener implements OnInvitationReceivedListener {

	@Override
	public void onInvitationReceived(Invitation invitation) {

		Log.d(AndroidNativeBridge.TAG, "onInvitationReceived+");
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnInvitationReceived", invitation.getInvitationId());
		
	}

	@Override
	public void onInvitationRemoved(String invitationId) {
		Log.d(AndroidNativeBridge.TAG, "onInvitationRemoved+");
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnInvitationRemoved", invitationId);
		
	}

}
